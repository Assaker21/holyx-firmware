#ifndef BLE_H__
#define BLE_H__

#include <stdint.h>
#include <stdbool.h>

void ble_init(void);

void ble_start_advertising(void);

#endif
