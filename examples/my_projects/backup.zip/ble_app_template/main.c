#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "app_error.h"
#include "app_timer.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_srv_common.h"
#include "response_handler.h"
#include "nrf.h"
#include "nrf_ble_gatt.h"
#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "nrf_pwr_mgmt.h"
#include "nrf_sdh.h"
#include "nrf_sdh_ble.h"

/* ===== User-visible definitions ===== */
#define DEVICE_NAME "HOLYX-223542"
#define APP_ADV_INTERVAL 64 /* 40 ms  */
#define APP_ADV_DURATION 0  /* keep advertising             */
#define APP_BLE_CONN_CFG_TAG 1
#define APP_BLE_OBSERVER_PRIO 3
/* ==================================== */

/* ---- Custom UUIDs ---- */
#define SERVICE_UUID_BASE                                                                              \
    {                                                                                                  \
        0xFB, 0x34, 0x9B, 0x5F, 0x80, 0x00, 0x00, 0x80, 0x00, 0x10, 0x00, 0x00, 0x34, 0x12, 0x00, 0x00 \
    }
#define SERVICE_UUID_SHORT 0x1234
#define CHAR_UUID_SHORT 0x5678
static uint8_t m_uuid_type;
static uint16_t m_service_handle;
static ble_gatts_char_handles_t m_char_handles;
static ble_gatts_char_handles_t m_char_handles_timestamp;
static ble_gatts_char_handles_t m_char_handles_image;

/* ---- BLE/GATT/ADV handles ---- */
static uint16_t m_conn_handle = BLE_CONN_HANDLE_INVALID;
NRF_BLE_GATT_DEF(m_gatt);
BLE_ADVERTISING_DEF(m_adv);

/* ========= Utility ========= */
static void logs_init(void)
{
    NRF_LOG_INIT(NULL);
    NRF_LOG_DEFAULT_BACKENDS_INIT();
}

static void power_init(void)
{
    APP_ERROR_CHECK(nrf_pwr_mgmt_init());
}
/* ============================ */

/* ========= GAP ============= */
static void gap_params_init(void)
{
    ble_gap_conn_params_t cp = {0};
    ble_gap_conn_sec_mode_t sec_mode;
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);

    sd_ble_gap_device_name_set(&sec_mode, (const uint8_t *)DEVICE_NAME,
        strlen(DEVICE_NAME));

    cp.min_conn_interval = MSEC_TO_UNITS(7.5, UNIT_1_25_MS); // MSEC_TO_UNITS(20, UNIT_1_25_MS);
    cp.max_conn_interval = MSEC_TO_UNITS(7.5, UNIT_1_25_MS); // MSEC_TO_UNITS(40, UNIT_1_25_MS);
    cp.slave_latency = 0;
    cp.conn_sup_timeout = MSEC_TO_UNITS(4000, UNIT_10_MS);
    sd_ble_gap_ppcp_set(&cp);
}
/* ============================ */

/* ========= GATT ============ */
static void gatt_init(void)
{
    APP_ERROR_CHECK(nrf_ble_gatt_init(&m_gatt, NULL));
}
/* ============================ */

/* ========= Custom service & char ======== */
static void service_init(void)
{
    ret_code_t err;
    ble_uuid_t svc_uuid;
    ble_uuid128_t base_uuid = {SERVICE_UUID_BASE};

    err = sd_ble_uuid_vs_add(&base_uuid, &m_uuid_type);
    APP_ERROR_CHECK(err);

    svc_uuid.type = m_uuid_type;
    svc_uuid.uuid = SERVICE_UUID_SHORT;

    err = sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY,
        &svc_uuid,
        &m_service_handle);
    APP_ERROR_CHECK(err);

    /* Characteristic: write / write-without-response */
    ble_gatts_char_md_t char_md = {0};
    ble_gatts_attr_md_t attr_md = {0};
    ble_gatts_attr_t attr = {0};
    uint8_t init_val = 0;

    char_md.char_props.write = 1;
    char_md.char_props.write_wo_resp = 1;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&attr_md.write_perm);
    attr_md.vloc = BLE_GATTS_VLOC_STACK;
    attr_md.vlen = 1;

    ble_uuid_t char_uuid;
    char_uuid.type = m_uuid_type;
    char_uuid.uuid = CHAR_UUID_SHORT;

    attr.p_uuid = &char_uuid;
    attr.p_attr_md = &attr_md;
    attr.init_len = sizeof(init_val);
    attr.max_len = 27; /* full extended-MTU packet */
    attr.p_value = &init_val;

    err = sd_ble_gatts_characteristic_add(m_service_handle,
        &char_md,
        &attr,
        &m_char_handles);
    APP_ERROR_CHECK(err);

    /* Second Characteristic: write / write-without-response */
    ble_gatts_char_md_t char2_md = {0};
    ble_gatts_attr_md_t attr2_md = {0};
    ble_gatts_attr_t attr2 = {0};
    uint8_t init_val2 = 0;

    char2_md.char_props.write = 1;
    char2_md.char_props.write_wo_resp = 1;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&attr2_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&attr2_md.write_perm);
    attr2_md.vloc = BLE_GATTS_VLOC_STACK;
    attr2_md.vlen = 1;

    ble_uuid_t char2_uuid;
    char2_uuid.type = m_uuid_type;
    char2_uuid.uuid = 0x5679; // NEW CHARACTERISTIC UUID

    attr2.p_uuid = &char2_uuid;
    attr2.p_attr_md = &attr2_md;
    attr2.init_len = sizeof(init_val2);
    attr2.max_len = 27;
    attr2.p_value = &init_val2;

    err = sd_ble_gatts_characteristic_add(m_service_handle,
        &char2_md,
        &attr2,
        &m_char_handles_timestamp);
    APP_ERROR_CHECK(err);

    /* Second Characteristic: write / write-without-response */
    ble_gatts_char_md_t char3_md = {0};
    ble_gatts_attr_md_t attr3_md = {0};
    ble_gatts_attr_t attr3 = {0};
    uint8_t init_val3 = 0;

    char3_md.char_props.write = 1;
    char3_md.char_props.write_wo_resp = 1;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&attr3_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&attr3_md.write_perm);
    attr3_md.vloc = BLE_GATTS_VLOC_STACK;
    attr3_md.vlen = 1;

    ble_uuid_t char3_uuid;
    char3_uuid.type = m_uuid_type;
    char3_uuid.uuid = 0x6679; // NEW CHARACTERISTIC UUID

    attr3.p_uuid = &char3_uuid;
    attr3.p_attr_md = &attr3_md;
    attr3.init_len = sizeof(init_val3);
    attr3.max_len = 27;
    attr3.p_value = &init_val3;

    err = sd_ble_gatts_characteristic_add(m_service_handle,
        &char3_md,
        &attr3,
        &m_char_handles_image);
    APP_ERROR_CHECK(err);
}
/* ======================================== */

/* ========= Advertising =================== */
static void advertising_init(void)
{
    ble_advdata_uuid_list_t adv_uuids;
    ble_uuid_t uuid = {SERVICE_UUID_SHORT, m_uuid_type};
    adv_uuids.uuid_cnt = 1;
    adv_uuids.p_uuids = &uuid;

    ble_advertising_init_t init = {0};
    init.advdata.name_type = BLE_ADVDATA_FULL_NAME;
    init.advdata.flags = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE;
    init.advdata.uuids_complete = adv_uuids;

    init.config.ble_adv_fast_enabled = true;
    init.config.ble_adv_fast_interval = APP_ADV_INTERVAL;
    init.config.ble_adv_fast_timeout = APP_ADV_DURATION;

    APP_ERROR_CHECK(ble_advertising_init(&m_adv, &init));
    ble_advertising_conn_cfg_tag_set(&m_adv, APP_BLE_CONN_CFG_TAG);
}

static void advertising_start(void)
{
    APP_ERROR_CHECK(ble_advertising_start(&m_adv, BLE_ADV_MODE_FAST));
}
/* ======================================== */

/* ========= BLE events =================== */
static void ble_evt_handler(ble_evt_t const *evt, void *ctx)
{
    switch (evt->header.evt_id)
    {
    case BLE_GAP_EVT_CONNECTED:
        printf("Connected\r\n");
        m_conn_handle = evt->evt.gap_evt.conn_handle;
        break;

    case BLE_GAP_EVT_DISCONNECTED:
        printf("Disconnected\r\n");
        m_conn_handle = BLE_CONN_HANDLE_INVALID;
        advertising_start();
        break;

    case BLE_GATTS_EVT_WRITE:
    {
        const ble_gatts_evt_write_t *w = &evt->evt.gatts_evt.params.write;
        if (w->handle == m_char_handles.value_handle)
        {
            printf("Received on auth (%u bytes):\r\n", w->len);
            for (uint16_t i = 0; i < w->len; ++i)
                printf("%02X ", w->data[i]);
            printf("\r\n");
        }
        else if (w->handle == m_char_handles_timestamp.value_handle)
        {
            printf("Received on timestamp (%u bytes):\r\n", w->len);
            for (uint16_t i = 0; i < w->len; ++i)
                printf("%02X ", w->data[i]);
            printf("\r\n");
        }
        else if (w->handle == m_char_handles_image.value_handle)
        {
            printf("Received on image (%u bytes):\r\n", w->len);
            for (uint16_t i = 0; i < w->len; ++i)
                printf("%02X ", w->data[i]);
            printf("\r\n");

            image_receiver_handle_chunk(w->data, w->len);
        }
    }
    break;
    case BLE_GAP_EVT_DATA_LENGTH_UPDATE_REQUEST:
    {
        ble_gap_data_length_params_t dl_params;
        memset(&dl_params, 0, sizeof(dl_params));
        // Let the SoftDevice decide the best option
        sd_ble_gap_data_length_update(evt->evt.gap_evt.conn_handle, &dl_params, NULL);
    }
    break;

    case BLE_GAP_EVT_DATA_LENGTH_UPDATE:
        // Optionally log negotiated DLE length
        break;

    case BLE_GATTS_EVT_EXCHANGE_MTU_REQUEST:
    {
        uint16_t mtu = NRF_SDH_BLE_GATT_MAX_MTU_SIZE;
        sd_ble_gatts_exchange_mtu_reply(evt->evt.gatts_evt.conn_handle, mtu);
    }
    break;

    default:
        break;
    }
}
/* ======================================== */

/* ========= BLE stack ==================== */
static void ble_stack_init(void)
{
    uint32_t ram_start = 0;
    ret_code_t err_code;

    APP_ERROR_CHECK(nrf_sdh_enable_request());

    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
    APP_ERROR_CHECK(err_code);
    if (err_code != NRF_SUCCESS)
    {
        printf("default_cfg_set error: 0x%08X\n", err_code);
    }
    printf("RAM start: 0x%08X\n", ram_start);

    err_code = nrf_sdh_ble_enable(&ram_start);
    if (err_code != NRF_SUCCESS)
    {
        printf("Enable BLE failed: 0x%08X\n", err_code);
    }

    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
    APP_ERROR_CHECK(err_code);
}

/* ======================================== */

int main(void)
{
    image_receiver_init("John");
    logs_init();
    APP_ERROR_CHECK(app_timer_init());
    power_init();
    ble_stack_init();
    gap_params_init();
    gatt_init();
    service_init();
    advertising_init();

    printf("Firmware ready � waiting for RN app �\r\n");
    advertising_start();

    for (;;)
    {
        if (!NRF_LOG_PROCESS())
            nrf_pwr_mgmt_run();
    }
}