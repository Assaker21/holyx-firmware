#include "ble_api.h"
#include "epd.h"
#include "rtc.h"
#include "power_manager.h"
#include "nrf_gpio.h"

#include "nrf_delay.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int turn_off_ready = 0;

int parse_unix_timestamp_string(const char *timestamp_str, rtc_datetime_t *dt)
{
    if (!timestamp_str || strlen(timestamp_str) != 10 || !dt)
        return -1;

    time_t timestamp = (time_t)strtoul(timestamp_str, NULL, 10);
    struct tm *tm_utc = gmtime(&timestamp);

    if (!tm_utc)
        return -2;

    dt->sec = tm_utc->tm_sec;
    dt->min = tm_utc->tm_min;
    dt->hour = tm_utc->tm_hour;
    dt->wday = tm_utc->tm_wday;
    dt->mday = tm_utc->tm_mday;
    dt->month = tm_utc->tm_mon + 1;
    dt->year = (tm_utc->tm_year >= 100) ? (tm_utc->tm_year - 100) : 0;

    return 0;
}

void handle_frame(const uint8_t *image_data, size_t image_len, const char *timestamp)
{
    printf("Callback Timestamp: %s\n\r", timestamp);
    rtc_datetime_t dt;

    if (parse_unix_timestamp_string(timestamp, &dt) == 0)
    {
        printf("Parsed Date: %02u-%02u-%02u %02u:%02u:%02u (WDay: %u)\n\r",
            dt.year, dt.month, dt.mday,
            dt.hour, dt.min, dt.sec,
            dt.wday);

        printf("Setting RTC to: %02u-%02u-%02u %02u:%02u:%02u\n\r",
            dt.year, dt.month, dt.mday,
            dt.hour, dt.min, dt.sec);

        ret_code_t err = rtc_set_datetime(&dt);
        if (err != NRF_SUCCESS)
        {
            printf("Failed to set RTC time: %d\n\r", err);
            return;
        }

        // Set alarm 1 minute from the set time
        uint8_t alarm_min = (dt.min + 2) % 60;
        uint8_t alarm_hour = dt.hour;

        // Handle hour rollover if minute wrapped around
        if (alarm_min == 0)
        {
            alarm_hour = (dt.hour + 1) % 24;
        }

        printf("Setting alarm for %02u:%02u\n\r", alarm_hour, alarm_min);

        err = rtc_set_alarm_time(alarm_hour, alarm_min);
        if (err == NRF_SUCCESS)
        {
            printf("Alarm set successfully!\n\r");
        }
        else
        {
            printf("Failed to set alarm: %d\n\r", err);
            return;
        }

        // Verify the alarm was set correctly
        rtc_alarm_t read_back;
        if (rtc_get_alarm(&read_back) == NRF_SUCCESS)
        {
            printf("Alarm verification: %02u:%02u\n\r", read_back.hour, read_back.min);
        }

        // Optional: Display image on EPD
        if (image_data && image_len > 0)
        {
            printf("Updating display with %zu bytes of image data\n\r", image_len);
            // epd_display_image(image_data, image_len);
        }

        nrf_delay_ms(200);
        turn_off_reset_required();
        
    }
    else
    {
        printf("Invalid timestamp input.\n\r");
    }
}

int main(void)
{
    printf("Initializing BLE and RTC...\n");

    //epd_spi_init();
  
    // Initialize RTC first
    rtc_init();
    clear_alarm_flag();
    printf("RTC initialized\n\r");

    // Initialize BLE
    ble_api_init(handle_frame);
    printf("BLE initialized\n\r");

    NRF_GPIO->LATCH = 1UL << WAKE_PIN;

    nrf_gpio_cfg_sense_input(WAKE_PIN,
                             WAKE_PULL,
                             WAKE_POLARITY);

    printf("System ready, waiting for BLE data...\n\r");

    while (1)
    {
      
    }
}